
package com.mycompany.rest.api.exceptions;

/**
 *
 * @author Student
 */
public class LinkedResourceNotFoundException extends RuntimeException { 
    public LinkedResourceNotFoundException (String message) {
        super(message);
    }
}

