package com.mycompany.rest.api.resources;

import com.mycompany.rest.api.models.Room;


import jakarta.ws.rs.*;
import jakarta.ws.rs.core.*;
import com.mycompany.rest.api.exceptions.RoomNotEmptyException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Path("/api/v1/room")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class RoomResource {

    private static final Map<String, Room> rooms = new ConcurrentHashMap<>();


    @GET
    public Collection<Room> getAllRooms() {
        return rooms.values();
    }

    @POST
    public Response createRoom(Room room) {

        if (room.getId() == null || room.getId().isBlank()) {
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity("Room ID is required")
                    .build();
        }

        if (rooms.containsKey(room.getId())) {
            return Response.status(Response.Status.CONFLICT)
                    .entity("Room ID already exists")
                    .build();
        }

        rooms.put(room.getId(), room);

        return Response.status(Response.Status.CREATED)
                .entity(room)
                .build();
    }

    @GET
    @Path("/{roomId}")
    public Response getRoom(@PathParam("roomId") String roomId) {
        Room room = rooms.get(roomId);

        if (room == null) {
            return Response.status(Response.Status.NOT_FOUND)
                    .entity("Room not found")
                    .build();
        }

        return Response.ok(room).build();
    }

    @DELETE
@Path("/{roomId}")
public Response deleteRoom(@PathParam("roomId") String roomId) {

    Room room = rooms.get(roomId);

    if (room == null) {
        return Response.status(Response.Status.NOT_FOUND)
                .entity("Room not found")
                .build();
    }

    boolean hasSensors = SensorResource.getSensors()
            .values()
            .stream()
            .anyMatch(sensor -> sensor.getRoomId().equals(roomId));

    if (hasSensors) {
        throw new RoomNotEmptyException
        ("This room is currently occupied by active hardware.");
    }

    rooms.remove(roomId);

    return Response.noContent().build();
}
    public static boolean roomExists(String id) {
    return rooms.containsKey(id);
}
}

