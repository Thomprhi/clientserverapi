package com.mycompany.rest.api.resources;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import com.mycompany.rest.api.exceptions.LinkedResourceNotFoundException;

@Path("/api/v1/sensor-room")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class SensorRoomResource {

    private static Map<Integer, Map<String, Object>> rooms = new ConcurrentHashMap<>();
    private static final AtomicInteger idCounter = new AtomicInteger(1);

    @GET
    public Collection<Map<String, Object>> getAllRooms() {
        return rooms.values();
    }

    @POST
    public Response createRoom(Map<String, Object> room) {

        int id = idCounter.getAndIncrement();
        room.put("id", id);

        rooms.put(id, room);

        return Response.status(Response.Status.CREATED)
                .entity(room)
                .build();
    }

    @GET
    @Path("/{id}")
    public Response getRoom(@PathParam("id") int id) {

        Map<String, Object> room = rooms.get(id);

        if (room == null) {
            throw new LinkedResourceNotFoundException("This room does not exist");
        }

        return Response.ok(room).build();
    }

    @DELETE
    @Path("/{id}")
    public Response deleteRoom(@PathParam("id") int id) {

        Map<String, Object> removedRoom = rooms.remove(id);

        if (removedRoom == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        }

        return Response.ok().build();
    }

    public static boolean roomExists(int id) {
        return rooms.containsKey(id);
    }
}