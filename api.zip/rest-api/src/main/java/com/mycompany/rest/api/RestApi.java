
package com.mycompany.rest.api;

import org.glassfish.grizzly.http.server.HttpServer;
import org.glassfish.jersey.grizzly2.httpserver.GrizzlyHttpServerFactory;
import org.glassfish.jersey.server.ResourceConfig;

import java.net.URI;

public class RestApi {

    public static final String BASE_URI = "http://localhost:8080/";

    public static void main(String[] args) {
        ResourceConfig rc = new ResourceConfig()
                .packages("com.mycompany.rest.api");

        HttpServer server = GrizzlyHttpServerFactory.createHttpServer(
                URI.create(BASE_URI),
                rc
        );

        System.out.println("Server started at " + BASE_URI);

        // keeps server running
        Runtime.getRuntime().addShutdownHook(new Thread(server::shutdownNow));
    }
}