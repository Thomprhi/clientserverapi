package com.mycompany.rest.api.resources;

import com.mycompany.rest.api.models.Sensor;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.*;
import java.util.*;
import java.util.concurrent.*;


@Path("/api/v1/sensor")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class SensorResource {

    private static final Map<String, Sensor> sensors = new ConcurrentHashMap<>();
    
            
    @GET
    public Collection<Sensor> getAllSensors() {
        return sensors.values();
    }

    @POST
    public Response createSensor(Sensor sensor) {
   
        // validate room exists
        if (!RoomResource.roomExists(sensor.getRoomId())) {
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity("Invalid roomId: room does not exist")
                    .build();
        }

        String id = UUID.randomUUID().toString();
sensor.setId(id);

        sensors.put(id, sensor);

        return Response.status(Response.Status.CREATED)
                .entity(sensor)
                .build();
    }

    @GET
    @Path("/{sensorId}")
    public Response getSensor(@PathParam("sensorId") String sensorId) {
        Sensor sensor = sensors.get(sensorId);

        if (sensor == null) {
            return Response.status(Response.Status.NOT_FOUND)
                    .entity("Sensor not found")
                    .build();
        }

        return Response.ok(sensor).build();
    }

    @DELETE
    @Path("/{sensorId}")
    public Response deleteSensor(@PathParam("sensorId") int sensorId) {
        Sensor removed = sensors.remove(sensorId);

        if (removed == null) {
            return Response.status(Response.Status.NOT_FOUND)
                    .entity("Sensor not found")
                    .build();
        }

        return Response.noContent().build();
    }

    public static Map<String, Sensor> getSensors() {
        return sensors;
    }
}